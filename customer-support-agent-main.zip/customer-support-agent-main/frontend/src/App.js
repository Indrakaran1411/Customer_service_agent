import React, { useState } from 'react';
import axios from 'axios';
import { Box, VStack, Heading, Container, Flex, Spinner, Text, useToast, IconButton, useColorMode } from '@chakra-ui/react';
import { FiMoon, FiSun } from 'react-icons/fi';
import ChatWindow from './components/ChatWindow';
import InputBox from './components/InputBox';

const API_URL = 'http://localhost:8000/chat'; // Your backend URL

function App() {
  const [messages, setMessages] = useState([
    { sender: 'agent', text: "Hello! How can I help you today?", intent: "Greeting" }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const toast = useToast();
  const { colorMode, toggleColorMode } = useColorMode();

  const handleSendMessage = async (text) => {
    const newUserMessage = { sender: 'user', text };
    setMessages((prevMessages) => [...prevMessages, newUserMessage]);
    setIsLoading(true);

    try {
      const response = await axios.post(API_URL, { query: text });
      const agentData = response.data;
      
      const newAgentMessage = {
        sender: 'agent',
        text: agentData.message,
        intent: agentData.intent,
        escalate: agentData.escalate,
        escalationReason: agentData.escalation_reason,
        kbArticle: agentData.kb_article_found,
        debugInfo: agentData.debug_info // Include debug info
      };
      setMessages((prevMessages) => [...prevMessages, newAgentMessage]);

    } catch (error) {
      console.error("Error sending message:", error);
      const errorMessage = error.response?.data?.detail || "Sorry, something went wrong. Please try again.";
      const newAgentMessage = { sender: 'agent', text: `Error: ${errorMessage}`, intent: "Error" };
      setMessages((prevMessages) => [...prevMessages, newAgentMessage]);
      toast({
        title: "API Error",
        description: errorMessage,
        status: "error",
        duration: 5000,
        isClosable: true,
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Container maxW="container.md" p={0} height="100vh">
      <Flex direction="column" height="100%">
        <Flex 
            as="header" 
            align="center" 
            justify="space-between" 
            p={4} 
            borderBottomWidth="1px"
            bg={colorMode === 'light' ? 'gray.50' : 'gray.700'}
        >
          <Heading size="md">Customer Support Agent</Heading>
          <IconButton
            icon={colorMode === 'light' ? <FiMoon /> : <FiSun />}
            onClick={toggleColorMode}
            aria-label="Toggle dark mode"
            variant="ghost"
          />
        </Flex>
        
        <ChatWindow messages={messages} />
        
        {isLoading && (
          <Flex justify="center" p={2}>
            <Spinner size="sm" />
            <Text ml={2} fontSize="sm">Agent is thinking...</Text>
          </Flex>
        )}
        
        <InputBox onSendMessage={handleSendMessage} isLoading={isLoading} />
      </Flex>
    </Container>
  );
}

export default App;