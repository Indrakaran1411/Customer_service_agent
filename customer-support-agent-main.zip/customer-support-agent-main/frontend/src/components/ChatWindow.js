import React, { useEffect, useRef } from 'react';
import {
  Box,
  VStack,
  Text,
  Tag,
  Alert,
  AlertIcon,
  AlertTitle,
  AlertDescription,
  Code,
  Card,
  CardHeader,
  CardBody,
  Heading,
  Kbd, // Kbd was in the original, might not be used, but keeping for consistency
  Badge,
  HStack // <--- ADD HStack HERE
} from '@chakra-ui/react';
import { FiAlertTriangle, FiInfo, FiThumbsUp, FiMessageSquare, FiUser, FiCpu } from 'react-icons/fi';

const ChatWindow = ({ messages }) => {
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);

  const getMessageBg = (sender) => (sender === 'user' ? 'blue.50' : 'gray.100');
  const getMessageAlign = (sender) => (sender === 'user' ? 'flex-end' : 'flex-start');
  const getIcon = (sender) => (sender === 'user' ? <FiUser /> : <FiCpu />);

  return (
    <VStack spacing={4} p={4} overflowY="auto" flexGrow={1} alignItems="stretch">
      {messages.map((msg, index) => (
        <Box
          key={index}
          alignSelf={getMessageAlign(msg.sender)}
          maxWidth="75%"
        >
          <Card
            bg={getMessageBg(msg.sender)}
            variant="outline"
            size="sm"
          >
            <CardHeader pb={1}>
                {/* This is where HStack is used */}
                <HStack>
                    {getIcon(msg.sender)}
                    <Heading size="xs" textTransform="capitalize">{msg.sender}</Heading>
                    {msg.sender === 'agent' && msg.intent && (
                        <Badge colorScheme="purple" variant="subtle">{msg.intent}</Badge>
                    )}
                </HStack>
            </CardHeader>
            <CardBody pt={1}>
              <Text whiteSpace="pre-wrap">{msg.text}</Text>
              {msg.sender === 'agent' && msg.kbArticle && (
                <Alert status="info" variant="subtle" mt={2} borderRadius="md">
                  <AlertIcon as={FiInfo} />
                  <Box flex="1">
                    <AlertTitle fontSize="sm">Relevant KB Article: "{msg.kbArticle.topic}"</AlertTitle>
                    <AlertDescription display="block" fontSize="xs" mt={1}>
                      <Text noOfLines={3}><i>{msg.kbArticle.answer}</i></Text>
                      <Text fontSize="xx-small" color="gray.500">Score: {msg.kbArticle.score?.toFixed(2)}</Text>
                    </AlertDescription>
                  </Box>
                </Alert>
              )}
              {msg.sender === 'agent' && msg.escalate && (
                <Alert status="warning" variant="left-accent" mt={2} borderRadius="md">
                  <AlertIcon as={FiAlertTriangle} />
                  <Box flex="1">
                    <AlertTitle fontSize="sm">Escalation Recommended</AlertTitle>
                    {msg.escalationReason && (
                      <AlertDescription display="block" fontSize="xs">
                        Reason: {msg.escalationReason}
                      </AlertDescription>
                    )}
                  </Box>
                </Alert>
              )}
               {msg.sender === 'agent' && msg.debugInfo && (
                 <Box mt={2} p={2} bg="gray.50" borderRadius="md">
                    <Text fontSize="xs" fontWeight="bold" color="gray.600">Debug Info:</Text>
                    <Code fontSize="2xs" colorScheme="gray" p={1} display="block" whiteSpace="pre-wrap">
                        {JSON.stringify(msg.debugInfo, null, 2)}
                    </Code>
                 </Box>
               )}
            </CardBody>
          </Card>
        </Box>
      ))}
      <div ref={messagesEndRef} />
    </VStack>
  );
};

export default ChatWindow;