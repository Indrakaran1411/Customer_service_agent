import React, { useState } from 'react';
import { Input, Button, HStack, Box } from '@chakra-ui/react';
import { FiSend } from 'react-icons/fi';

const InputBox = ({ onSendMessage, isLoading }) => {
  const [inputValue, setInputValue] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (inputValue.trim()) {
      onSendMessage(inputValue.trim());
      setInputValue('');
    }
  };

  return (
    <Box p={4} borderTopWidth="1px">
      <form onSubmit={handleSubmit}>
        <HStack>
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Type your message..."
            isDisabled={isLoading}
            flexGrow={1}
          />
          <Button 
            type="submit" 
            colorScheme="blue" // Chakra UI color scheme
            isLoading={isLoading}
            leftIcon={<FiSend />}
          >
            Send
          </Button>
        </HStack>
      </form>
    </Box>
  );
};

export default InputBox;